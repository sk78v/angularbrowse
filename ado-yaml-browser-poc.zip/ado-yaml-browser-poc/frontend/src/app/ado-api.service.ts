import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Project { id: string; name: string; }
export interface Repository { id: string; name: string; defaultBranch?: string; }
export interface BrowserItem { path: string; name: string; isFolder: boolean; commitId?: string; }
export interface YamlFile {
  project: string;
  repositoryId: string;
  branch: string;
  path: string;
  commitId?: string;
  content: string;
}

@Injectable({ providedIn: 'root' })
export class AdoApiService {
  private http = inject(HttpClient);
  private base = '/api/ado';

  getProjects(): Observable<Project[]> {
    return this.http.get<Project[]>(`${this.base}/projects`);
  }

  getRepositories(project: string): Observable<Repository[]> {
    return this.http.get<Repository[]>(
      `${this.base}/projects/${encodeURIComponent(project)}/repositories`
    );
  }

  getBranches(project: string, repositoryId: string): Observable<string[]> {
    return this.http.get<string[]>(
      `${this.base}/projects/${encodeURIComponent(project)}/repositories/${encodeURIComponent(repositoryId)}/branches`
    );
  }

  browse(project: string, repositoryId: string, branch: string, path: string): Observable<BrowserItem[]> {
    const params = new HttpParams()
      .set('project', project)
      .set('repositoryId', repositoryId)
      .set('branch', branch)
      .set('path', path);

    return this.http.get<BrowserItem[]>(`${this.base}/browse`, { params });
  }

  getYaml(project: string, repositoryId: string, branch: string, path: string): Observable<YamlFile> {
    const params = new HttpParams()
      .set('project', project)
      .set('repositoryId', repositoryId)
      .set('branch', branch)
      .set('path', path);

    return this.http.get<YamlFile>(`${this.base}/yaml`, { params });
  }
}
