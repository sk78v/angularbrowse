import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AdoApiService, BrowserItem, Project, Repository, YamlFile } from './ado-api.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  private api = inject(AdoApiService);

  readonly rootPath = '/service-account-definitions';

  projects: Project[] = [];
  repositories: Repository[] = [];
  branches: string[] = [];
  items: BrowserItem[] = [];

  selectedProject = '';
  selectedRepository = '';
  selectedBranch = '';
  currentPath = this.rootPath;
  yaml?: YamlFile;

  loading = false;
  error = '';

  ngOnInit(): void {
    this.loading = true;
    this.api.getProjects().subscribe({
      next: x => { this.projects = x; this.loading = false; },
      error: e => this.fail(e)
    });
  }

  projectChanged(): void {
    this.repositories = [];
    this.branches = [];
    this.items = [];
    this.yaml = undefined;
    this.selectedRepository = '';
    this.selectedBranch = '';
    if (!this.selectedProject) return;

    this.loading = true;
    this.api.getRepositories(this.selectedProject).subscribe({
      next: x => { this.repositories = x; this.loading = false; },
      error: e => this.fail(e)
    });
  }

  repositoryChanged(): void {
    this.branches = [];
    this.items = [];
    this.yaml = undefined;
    this.selectedBranch = '';
    if (!this.selectedProject || !this.selectedRepository) return;

    this.loading = true;
    this.api.getBranches(this.selectedProject, this.selectedRepository).subscribe({
      next: x => { this.branches = x; this.loading = false; },
      error: e => this.fail(e)
    });
  }

  branchChanged(): void {
    this.currentPath = this.rootPath;
    this.yaml = undefined;
    if (this.selectedBranch) this.loadFolder(this.currentPath);
  }

  open(item: BrowserItem): void {
    if (item.isFolder) {
      this.loadFolder(item.path);
    } else {
      this.loading = true;
      this.api.getYaml(this.selectedProject, this.selectedRepository, this.selectedBranch, item.path)
        .subscribe({
          next: x => { this.yaml = x; this.loading = false; },
          error: e => this.fail(e)
        });
    }
  }

  up(): void {
    if (this.currentPath === this.rootPath) return;
    const parent = this.currentPath.substring(0, this.currentPath.lastIndexOf('/')) || '/';
    const safeParent = parent.length < this.rootPath.length ? this.rootPath : parent;
    this.loadFolder(safeParent);
  }

  downloadSelected(): void {
    if (!this.yaml) return;
    const blob = new Blob([this.yaml.content], { type: 'application/x-yaml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = this.yaml.path.split('/').pop() ?? 'config.yaml';
    a.click();
    URL.revokeObjectURL(url);
  }

  private loadFolder(path: string): void {
    this.loading = true;
    this.error = '';
    this.yaml = undefined;
    this.api.browse(this.selectedProject, this.selectedRepository, this.selectedBranch, path)
      .subscribe({
        next: x => {
          this.currentPath = path;
          this.items = x;
          this.loading = false;
        },
        error: e => this.fail(e)
      });
  }

  private fail(error: any): void {
    this.loading = false;
    this.error = error?.error?.error || error?.message || 'Request failed.';
  }
}
