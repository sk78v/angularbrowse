# Azure DevOps On-Prem YAML Browser POC

This POC contains:

- Angular UI for Project -> Repository -> Branch -> Folder/YAML navigation
- ASP.NET Core 8 backend
- Azure DevOps Server REST API integration
- PAT or Windows Integrated authentication
- Server-side restriction to a configured repository root path
- Only `.yaml` / `.yml` files are exposed in the browser
- YAML preview and browser download
- Commit ID returned with the selected file

## 1. Configure the backend

Edit:

`backend/AdoYamlBrowser.Api/appsettings.json`

Example for on-prem Azure DevOps Server:

```json
"AzureDevOps": {
  "BaseUrl": "https://myado.company.com/tfs/DefaultCollection",
  "ApiVersion": "7.0",
  "AllowedRootPath": "/service-account-definitions",
  "Authentication": {
    "Mode": "Pat",
    "Pat": "YOUR_PAT"
  }
}
```

Do not commit the PAT. For local development, prefer .NET User Secrets or an environment variable:

```powershell
cd backend/AdoYamlBrowser.Api
dotnet user-secrets init
dotnet user-secrets set "AzureDevOps:Authentication:Pat" "YOUR_PAT"
```

For Windows integrated authentication:

```json
"Authentication": {
  "Mode": "Windows",
  "Pat": ""
}
```

The account running the backend must then have read permission in Azure DevOps Server.

## 2. Run backend

```powershell
cd backend/AdoYamlBrowser.Api
dotnet restore
dotnet run --urls "https://localhost:7180"
```

Swagger:

`https://localhost:7180/swagger`

## 3. Run Angular

```powershell
cd frontend
npm install
npm start
```

Open:

`http://localhost:4200`

Angular uses `proxy.conf.json` to forward `/api` to the ASP.NET Core API.

## Backend API

- `GET /api/ado/projects`
- `GET /api/ado/projects/{project}/repositories`
- `GET /api/ado/projects/{project}/repositories/{repositoryId}/branches`
- `GET /api/ado/browse?project=...&repositoryId=...&branch=...&path=...`
- `GET /api/ado/yaml?project=...&repositoryId=...&branch=...&path=...`

## Security recommendations before production

1. Never expose a PAT to Angular/browser code.
2. Store the PAT in a secret store, environment variable, or protected configuration.
3. Prefer a read-only Azure DevOps identity with the minimum Code/Repo permissions required.
4. Keep `AllowedRootPath` restricted to the approved YAML configuration area.
5. Add application authentication/authorization to the ASP.NET API.
6. Validate the selected YAML against your service-account schema before provisioning.
7. Record project, repository ID, branch, path, commit ID, requester and request ID for auditability.
8. Consider pinning the provisioning execution to the returned commit ID instead of rereading the moving branch later.

## Azure DevOps Server API version

The API version supported depends on your installed Azure DevOps Server release. This POC makes it configurable in `appsettings.json`. If `7.0` is not supported by your server, set the version appropriate to your installed release.
