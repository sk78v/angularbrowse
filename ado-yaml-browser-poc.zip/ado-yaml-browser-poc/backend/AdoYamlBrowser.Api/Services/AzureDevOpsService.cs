using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using AdoYamlBrowser.Api.Models;
using Microsoft.Extensions.Options;

namespace AdoYamlBrowser.Api.Services;

public sealed class AzureDevOpsService
{
    private readonly HttpClient _httpClient;
    private readonly AzureDevOpsOptions _options;
    private readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web);

    public AzureDevOpsService(HttpClient httpClient, IOptions<AzureDevOpsOptions> options)
    {
        _httpClient = httpClient;
        _options = options.Value;

        if (string.IsNullOrWhiteSpace(_options.BaseUrl))
            throw new InvalidOperationException("AzureDevOps:BaseUrl is required.");

        _httpClient.BaseAddress = new Uri(_options.BaseUrl.TrimEnd('/') + "/");

        if (_options.Authentication.Mode.Equals("Pat", StringComparison.OrdinalIgnoreCase))
        {
            var pat = _options.Authentication.Pat;
            if (string.IsNullOrWhiteSpace(pat))
                throw new InvalidOperationException("PAT authentication selected but AzureDevOps:Authentication:Pat is empty.");

            var token = Convert.ToBase64String(Encoding.ASCII.GetBytes($":{pat}"));
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", token);
        }

        _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    }

    public async Task<IReadOnlyList<AdoProject>> GetProjectsAsync(CancellationToken cancellationToken)
    {
        var url = $"_apis/projects?$top=500&api-version={Esc(_options.ApiVersion)}";
        var response = await GetJsonAsync<AdoListResponse<AdoProject>>(url, cancellationToken);
        return response.Value.OrderBy(x => x.Name).ToList();
    }

    public async Task<IReadOnlyList<AdoRepository>> GetRepositoriesAsync(string project, CancellationToken cancellationToken)
    {
        var url = $"{EscPath(project)}/_apis/git/repositories?api-version={Esc(_options.ApiVersion)}";
        var response = await GetJsonAsync<AdoListResponse<AdoRepository>>(url, cancellationToken);
        return response.Value.OrderBy(x => x.Name).ToList();
    }

    public async Task<IReadOnlyList<string>> GetBranchesAsync(string project, string repositoryId, CancellationToken cancellationToken)
    {
        var url = $"{EscPath(project)}/_apis/git/repositories/{EscPath(repositoryId)}/refs?filter=heads/&api-version={Esc(_options.ApiVersion)}";
        var response = await GetJsonAsync<AdoListResponse<AdoRef>>(url, cancellationToken);

        return response.Value
            .Where(x => x.Name.StartsWith("refs/heads/", StringComparison.OrdinalIgnoreCase))
            .Select(x => x.Name["refs/heads/".Length..])
            .OrderBy(x => x)
            .ToList();
    }

    public async Task<IReadOnlyList<BrowserItemDto>> BrowseAsync(
        string project,
        string repositoryId,
        string branch,
        string path,
        CancellationToken cancellationToken)
    {
        var normalized = NormalizeAndAuthorizePath(path);

        var url = $"{EscPath(project)}/_apis/git/repositories/{EscPath(repositoryId)}/items" +
                  $"?scopePath={Esc(normalized)}" +
                  "&recursionLevel=OneLevel" +
                  $"&versionDescriptor.version={Esc(branch)}" +
                  "&versionDescriptor.versionType=branch" +
                  $"&api-version={Esc(_options.ApiVersion)}";

        var response = await GetJsonAsync<AdoListResponse<AdoGitItem>>(url, cancellationToken);

        // Azure DevOps can include the scope folder itself in the result. Exclude it.
        return response.Value
            .Where(x => !x.Path.Equals(normalized, StringComparison.OrdinalIgnoreCase))
            .Where(x => IsDirectChild(normalized, x.Path))
            .Where(x => x.IsFolder || IsYaml(x.Path))
            .Select(x => new BrowserItemDto(
                x.Path,
                System.IO.Path.GetFileName(x.Path.TrimEnd('/')),
                x.IsFolder,
                x.CommitId))
            .OrderByDescending(x => x.IsFolder)
            .ThenBy(x => x.Name)
            .ToList();
    }

    public async Task<YamlFileDto> GetYamlAsync(
        string project,
        string repositoryId,
        string branch,
        string path,
        CancellationToken cancellationToken)
    {
        var normalized = NormalizeAndAuthorizePath(path);
        if (!IsYaml(normalized))
            throw new ArgumentException("Only .yaml or .yml files can be retrieved.");

        var metadataUrl = $"{EscPath(project)}/_apis/git/repositories/{EscPath(repositoryId)}/items" +
                          $"?path={Esc(normalized)}" +
                          $"&versionDescriptor.version={Esc(branch)}" +
                          "&versionDescriptor.versionType=branch" +
                          $"&api-version={Esc(_options.ApiVersion)}";

        var metadata = await GetJsonAsync<AdoGitItem>(metadataUrl, cancellationToken);

        var contentUrl = $"{EscPath(project)}/_apis/git/repositories/{EscPath(repositoryId)}/items" +
                         $"?path={Esc(normalized)}" +
                         $"&versionDescriptor.version={Esc(branch)}" +
                         "&versionDescriptor.versionType=branch" +
                         "&includeContent=true" +
                         $"&api-version={Esc(_options.ApiVersion)}";

        using var request = new HttpRequestMessage(HttpMethod.Get, contentUrl);
        request.Headers.Accept.Clear();
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("text/plain"));

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        response.EnsureSuccessStatusCode();
        var content = await response.Content.ReadAsStringAsync(cancellationToken);

        return new YamlFileDto(project, repositoryId, branch, normalized, metadata.CommitId, content);
    }

    private async Task<T> GetJsonAsync<T>(string relativeUrl, CancellationToken cancellationToken)
    {
        using var response = await _httpClient.GetAsync(relativeUrl, cancellationToken);
        response.EnsureSuccessStatusCode();
        var json = await response.Content.ReadAsStringAsync(cancellationToken);
        return JsonSerializer.Deserialize<T>(json, _jsonOptions)
               ?? throw new InvalidOperationException("Azure DevOps returned an empty response.");
    }

    private string NormalizeAndAuthorizePath(string? path)
    {
        var requested = string.IsNullOrWhiteSpace(path) ? _options.AllowedRootPath : path;
        requested = requested!.Replace('\\', '/');
        if (!requested.StartsWith('/')) requested = "/" + requested;
        while (requested.Contains("//")) requested = requested.Replace("//", "/");

        var root = string.IsNullOrWhiteSpace(_options.AllowedRootPath) ? "/" : _options.AllowedRootPath.Replace('\\', '/');
        if (!root.StartsWith('/')) root = "/" + root;
        root = root.TrimEnd('/');
        if (root.Length == 0) root = "/";

        if (root != "/" &&
            !requested.Equals(root, StringComparison.OrdinalIgnoreCase) &&
            !requested.StartsWith(root + "/", StringComparison.OrdinalIgnoreCase))
        {
            throw new UnauthorizedAccessException($"Browsing is restricted to {root}.");
        }

        return requested;
    }

    private static bool IsDirectChild(string parent, string child)
    {
        var p = parent.TrimEnd('/');
        if (p.Length == 0) p = "/";
        var prefix = p == "/" ? "/" : p + "/";
        if (!child.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) return false;
        var rest = child[prefix.Length..];
        return rest.Length > 0 && !rest.Contains('/');
    }

    private static bool IsYaml(string path) =>
        path.EndsWith(".yaml", StringComparison.OrdinalIgnoreCase) ||
        path.EndsWith(".yml", StringComparison.OrdinalIgnoreCase);

    private static string Esc(string value) => Uri.EscapeDataString(value);
    private static string EscPath(string value) => Uri.EscapeDataString(value);
}
