using AdoYamlBrowser.Api.Models;
using AdoYamlBrowser.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<AzureDevOpsOptions>(builder.Configuration.GetSection("AzureDevOps"));
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddHttpClient<AzureDevOpsService>()
    .ConfigurePrimaryHttpMessageHandler(sp =>
    {
        var config = sp.GetRequiredService<IConfiguration>();
        var mode = config["AzureDevOps:Authentication:Mode"] ?? "Pat";

        return new HttpClientHandler
        {
            UseDefaultCredentials = mode.Equals("Windows", StringComparison.OrdinalIgnoreCase)
        };
    });

builder.Services.AddCors(options =>
{
    options.AddPolicy("Angular", p => p
        .WithOrigins("http://localhost:4200")
        .AllowAnyHeader()
        .AllowAnyMethod());
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseHttpsRedirection();
app.UseCors("Angular");
app.MapControllers();
app.Run();
