namespace AdoYamlBrowser.Api.Models;

public sealed class AzureDevOpsOptions
{
    public string BaseUrl { get; set; } = string.Empty;
    public string ApiVersion { get; set; } = "7.0";
    public string AllowedRootPath { get; set; } = "/";
    public AzureDevOpsAuthenticationOptions Authentication { get; set; } = new();
}

public sealed class AzureDevOpsAuthenticationOptions
{
    public string Mode { get; set; } = "Pat";
    public string Pat { get; set; } = string.Empty;
}
