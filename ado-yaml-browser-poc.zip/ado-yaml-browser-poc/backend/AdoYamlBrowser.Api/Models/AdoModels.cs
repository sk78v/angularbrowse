using System.Text.Json.Serialization;

namespace AdoYamlBrowser.Api.Models;

public sealed class AdoListResponse<T>
{
    [JsonPropertyName("count")]
    public int Count { get; set; }

    [JsonPropertyName("value")]
    public List<T> Value { get; set; } = [];
}

public sealed class AdoProject
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;
}

public sealed class AdoRepository
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    [JsonPropertyName("defaultBranch")]
    public string? DefaultBranch { get; set; }
}

public sealed class AdoRef
{
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    [JsonPropertyName("objectId")]
    public string ObjectId { get; set; } = string.Empty;
}

public sealed class AdoGitItem
{
    [JsonPropertyName("objectId")]
    public string? ObjectId { get; set; }

    [JsonPropertyName("gitObjectType")]
    public string GitObjectType { get; set; } = string.Empty;

    [JsonPropertyName("commitId")]
    public string? CommitId { get; set; }

    [JsonPropertyName("path")]
    public string Path { get; set; } = string.Empty;

    [JsonIgnore]
    public bool IsFolder => GitObjectType.Equals("tree", StringComparison.OrdinalIgnoreCase);
}

public sealed record BrowserItemDto(
    string Path,
    string Name,
    bool IsFolder,
    string? CommitId);

public sealed record YamlFileDto(
    string Project,
    string RepositoryId,
    string Branch,
    string Path,
    string? CommitId,
    string Content);
