using AdoYamlBrowser.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace AdoYamlBrowser.Api.Controllers;

[ApiController]
[Route("api/ado")]
public sealed class AdoController : ControllerBase
{
    private readonly AzureDevOpsService _ado;

    public AdoController(AzureDevOpsService ado) => _ado = ado;

    [HttpGet("projects")]
    public async Task<IActionResult> Projects(CancellationToken ct) =>
        Ok(await _ado.GetProjectsAsync(ct));

    [HttpGet("projects/{project}/repositories")]
    public async Task<IActionResult> Repositories(string project, CancellationToken ct) =>
        Ok(await _ado.GetRepositoriesAsync(project, ct));

    [HttpGet("projects/{project}/repositories/{repositoryId}/branches")]
    public async Task<IActionResult> Branches(string project, string repositoryId, CancellationToken ct) =>
        Ok(await _ado.GetBranchesAsync(project, repositoryId, ct));

    [HttpGet("browse")]
    public async Task<IActionResult> Browse(
        [FromQuery] string project,
        [FromQuery] string repositoryId,
        [FromQuery] string branch,
        [FromQuery] string? path,
        CancellationToken ct)
    {
        try
        {
            return Ok(await _ado.BrowseAsync(project, repositoryId, branch, path ?? string.Empty, ct));
        }
        catch (UnauthorizedAccessException ex)
        {
            return Forbid(ex.Message);
        }
    }

    [HttpGet("yaml")]
    public async Task<IActionResult> GetYaml(
        [FromQuery] string project,
        [FromQuery] string repositoryId,
        [FromQuery] string branch,
        [FromQuery] string path,
        CancellationToken ct)
    {
        try
        {
            return Ok(await _ado.GetYamlAsync(project, repositoryId, branch, path, ct));
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
        catch (UnauthorizedAccessException ex)
        {
            return Forbid(ex.Message);
        }
    }
}
